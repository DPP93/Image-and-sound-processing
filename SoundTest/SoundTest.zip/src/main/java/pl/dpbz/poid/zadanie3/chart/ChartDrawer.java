package pl.dpbz.poid.zadanie3.chart;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

import javax.swing.*;

/**
 * Created by Daniel on 2016-05-19.
 */
public class ChartDrawer extends JFrame{

    public static void drawChart(JFreeChart chart){
        ChartDrawer cd = new ChartDrawer();
        ChartPanel cp = new ChartPanel(chart);
        cd.setContentPane(cp);
        cd.setDefaultCloseOperation(EXIT_ON_CLOSE);
        cd.pack();
        cd.setVisible(true);
    }

}
